// DOM elements
const setupSection = document.getElementById('setup-section');
const statsSection = document.getElementById('stats-section');
const handleInput = document.getElementById('handle-input');
const saveHandleBtn = document.getElementById('save-handle');
const changeHandleBtn = document.getElementById('change-handle');
const userHandleEl = document.getElementById('user-handle');
const questionCountEl = document.getElementById('question-count');
const trackingStatusEl = document.getElementById('tracking-status');
const startBtn = document.getElementById('start-btn');
const resetBtn = document.getElementById('reset-btn');
const errorMsg = document.getElementById('error-msg');
const loading = document.getElementById('loading');

// Initialize popup
async function init() {
  const data = await chrome.storage.local.get(['cfHandle', 'isTracking', 'baselineCount', 'currentCount', 'startTime']);
  
  if (data.cfHandle) {
    showStatsSection(data.cfHandle);
    const count = data.isTracking ? (data.currentCount || 0) - (data.baselineCount || 0) : 0;
    updateStats(count);
    updateTrackingStatus(data.isTracking || false, data.startTime);
  } else {
    showSetupSection();
  }
}

// Show setup section
function showSetupSection() {
  setupSection.classList.remove('hidden');
  statsSection.classList.add('hidden');
}

// Show stats section
function showStatsSection(handle) {
  setupSection.classList.add('hidden');
  statsSection.classList.remove('hidden');
  userHandleEl.textContent = handle;
}

// Update stats display
function updateStats(count) {
  todayCountEl.textContent = count;
}

// Update tracking status display
function updateTrackingStatus(isTracking, startTime) {
  if (isTracking) {
    trackingStatusEl.textContent = 'Tracking active';
    trackingStatusEl.classList.add('tracking');
    startBtn.textContent = 'Stop Tracking';
    startBtn.classList.add('reset-btn');
    startBtn.classList.remove('start-btn');
  } else {
    trackingStatusEl.textContent = 'Not tracking';
    trackingStatusEl.classList.remove('tracking');
    startBtn.textContent = 'Start Tracking';
    startBtn.classList.add('start-btn');
    startBtn.classList.remove('reset-btn');
  }
}

// Fetch submissions from Codeforces API
async function fetchSubmissions(handle) {
  try {
    const response = await fetch(`https://codeforces.com/api/user.status?handle=${handle}&from=1&count=1000`);
    const data = await response.json();
    
    if (data.status !== 'OK') {
      throw new Error(data.comment || 'Failed to fetch submissions');
    }
    
    return data.result;
  } catch (error) {
    throw new Error(`API Error: ${error.message}`);
  }
}

// Count total problems solved
function countTotalProblems(submissions) {
  const solvedProblems = new Set();
  
  submissions.forEach(submission => {
    if (submission.verdict === 'OK') {
      const problemId = `${submission.problem.contestId}-${submission.problem.index}`;
      solvedProblems.add(problemId);
    }
  });
  
  return solvedProblems.size;
}

// Count problems solved after a certain timestamp
function countProblemsSince(submissions, timestampSeconds) {
  const solvedProblems = new Set();
  
  submissions.forEach(submission => {
    if (submission.verdict === 'OK' && submission.creationTimeSeconds >= timestampSeconds) {
      const problemId = `${submission.problem.contestId}-${submission.problem.index}`;
      solvedProblems.add(problemId);
    }
  });
  
  return solvedProblems.size;
}

// Show error message
function showError(message) {
  errorMsg.textContent = message;
  errorMsg.classList.remove('hidden');
  setTimeout(() => {
    errorMsg.classList.add('hidden');
  }, 5000);
}

// Show loading
function showLoading(show) {
  if (show) {
    loading.classList.remove('hidden');
  } else {
    loading.classList.add('hidden');
  }
}

// Update current problem count
async function updateCurrentCount(handle) {
  showLoading(true);
  errorMsg.classList.add('hidden');
  
  try {
    const submissions = await fetchSubmissions(handle);
    const totalCount = countTotalProblems(submissions);
    
    await chrome.storage.local.set({
      currentCount: totalCount,
      lastUpdate: Date.now()
    });
    
    const data = await chrome.storage.local.get(['isTracking', 'baselineCount']);
    if (data.isTracking) {
      const displayCount = totalCount - (data.baselineCount || 0);
      updateStats(displayCount);
    }
    
    showLoading(false);
    return totalCount;
  } catch (error) {
    showLoading(false);
    showError(error.message);
    return null;
  }
}

// Event listeners
saveHandleBtn.addEventListener('click', async () => {
  const handle = handleInput.value.trim();
  
  if (!handle) {
    showError('Please enter a valid handle');
    return;
  }
  
  showLoading(true);
  
  try {
    // Verify handle exists
    const submissions = await fetchSubmissions(handle);
    const totalCount = countTotalProblems(submissions);
    
    await chrome.storage.local.set({
      cfHandle: handle,
      currentCount: totalCount,
      baselineCount: 0,
      isTracking: false,
      lastUpdate: Date.now()
    });
    
    showLoading(false);
    showStatsSection(handle);
    updateStats(0);
    updateTrackingStatus(false);
  } catch (error) {
    showLoading(false);
    showError(error.message);
  }
});

changeHandleBtn.addEventListener('click', () => {
  handleInput.value = '';
  showSetupSection();
});

startBtn.addEventListener('click', async () => {
  const data = await chrome.storage.local.get(['cfHandle', 'isTracking', 'currentCount']);
  
  if (!data.cfHandle) return;
  
  if (data.isTracking) {
    // Stop tracking
    await chrome.storage.local.set({
      isTracking: false,
      baselineCount: 0
    });
    updateStats(0);
    updateTrackingStatus(false);
  } else {
    // Start tracking
    showLoading(true);
    const totalCount = await updateCurrentCount(data.cfHandle);
    
    if (totalCount !== null) {
      await chrome.storage.local.set({
        isTracking: true,
        baselineCount: totalCount,
        startTime: Date.now()
      });
      updateStats(0);
      updateTrackingStatus(true, Date.now());
    }
  }
});

resetBtn.addEventListener('click', async () => {
  const data = await chrome.storage.local.get(['cfHandle', 'isTracking']);
  
  if (!data.cfHandle) return;
  
  if (confirm('Are you sure you want to reset the count?')) {
    if (data.isTracking) {
      showLoading(true);
      const totalCount = await updateCurrentCount(data.cfHandle);
      
      if (totalCount !== null) {
        await chrome.storage.local.set({
          baselineCount: totalCount
        });
        updateStats(0);
      }
    } else {
      updateStats(0);
    }
  }
});

// Initialize on load
init();
