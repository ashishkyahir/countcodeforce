// Background service worker for periodic updates when tracking is active

// Create alarm for periodic updates (every 10 minutes)
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create('updateStats', { periodInMinutes: 10 });
});

// Fetch submissions from Codeforces API
async function fetchSubmissions(handle) {
  try {
    const response = await fetch(`https://codeforces.com/api/user.status?handle=${handle}&from=1&count=1000`);
    const data = await response.json();
    
    if (data.status !== 'OK') {
      return null;
    }
    
    return data.result;
  } catch (error) {
    console.error('Error fetching submissions:', error);
    return null;
  }
}

// Count total problems solved
function countTotalProblems(submissions) {
  const solvedProblems = new Set();
  
  submissions.forEach(submission => {
    if (submission.verdict === 'OK') {
      const problemId = `${submission.problem.contestId}-${submission.problem.index}`;
      solvedProblems.add(problemId);
    }
  });
  
  return solvedProblems.size;
}

// Update problem count and badge
async function updateProblemCount() {
  const data = await chrome.storage.local.get(['cfHandle', 'isTracking', 'baselineCount']);
  
  if (!data.cfHandle || !data.isTracking) {
    // Clear badge if not tracking
    chrome.action.setBadgeText({ text: '' });
    return;
  }
  
  const submissions = await fetchSubmissions(data.cfHandle);
  
  if (submissions) {
    const totalCount = countTotalProblems(submissions);
    const displayCount = totalCount - (data.baselineCount || 0);
    
    await chrome.storage.local.set({
      currentCount: totalCount,
      lastUpdate: Date.now()
    });
    
    // Update badge
    chrome.action.setBadgeText({ text: displayCount.toString() });
    chrome.action.setBadgeBackgroundColor({ color: '#667eea' });
  }
}

// Handle alarms
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'updateStats') {
    updateProblemCount();
  }
});

// Update on browser startup
chrome.runtime.onStartup.addListener(() => {
  updateProblemCount();
});
